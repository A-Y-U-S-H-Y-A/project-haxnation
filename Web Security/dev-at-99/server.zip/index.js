const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 8080;

// Middleware to parse the request body
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (like HTML) from the 'public' directory
app.use(express.static('public'));

// Define a route for the login form
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/login.html');
});

// Define a route to handle the login POST request
app.post('/login', (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    if (username === 'iamroot' && password === 'root') {
        res.send('HXN{PennyW!seP0undF00lish}');
    } else {
        res.send('Login failed. Please check your username and password.');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running at ${port}`);
});
