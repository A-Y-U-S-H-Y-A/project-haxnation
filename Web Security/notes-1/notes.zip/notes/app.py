from flask import Flask, session, redirect, url_for, render_template, request, flash

app = Flask(__name__)
app.secret_key = "qwerty"  # Weak Key

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        if username.lower() == "admin":
            flash("The username 'admin' is not allowed.", "error")
            return redirect(url_for('login'))
        if not username:
            flash("Username cannot be empty.", "error")
            return redirect(url_for('login'))
        session['username'] = username
        session['notes'] = []  # Initialize an empty notes list
        return redirect(url_for('notes'))
    return render_template('login.html')

@app.route('/notes', methods=['GET', 'POST'])
def notes():
    if 'username' not in session:
        return redirect(url_for('login'))
    if session['username'] == 'admin':
        session['notes'] = ['Well Done, HXN{$ession1nsecure}']
    if request.method == 'POST':
        note = request.form.get('note', '').strip()
        if note:
            session['notes'].append(note)
            flash("Note added!", "success")
        else:
            flash("Note cannot be empty.", "error")
        return redirect(url_for('notes'))
    
    return render_template('notes.html', username=session['username'], notes=session['notes'])

@app.route('/delete/<int:note_id>', methods=['POST'])
def delete_note(note_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    try:
        session['notes'].pop(note_id)
        flash("Note deleted!", "success")
    except IndexError:
        flash("Invalid note ID.", "error")
    return redirect(url_for('notes'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
